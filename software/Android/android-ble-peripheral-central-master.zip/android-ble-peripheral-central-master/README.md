Android Bluetooth Low Energy communication Sample
===================================
Bla Bla

Getting Started
------------
Bla Bla

Screenshots
-------------
<img src="screenshots/1.png" height="500" alt="Screenshot"/> <img src="screenshots/2.png" height="500" alt="Screenshot"/>
<img src="screenshots/3.png" height="500" alt="Screenshot"/> <img src="screenshots/4.png" height="500" alt="Screenshot"/>

Acknowledgements
------------
[android-BluetoothLeGatt][1]

[android-BluetoothAdvertisements][2]

[ble-test-peripheral-android][3]

[1]:https://github.com/googlesamples/android-BluetoothLeGatt/
[2]:https://github.com/googlesamples/android-BluetoothAdvertisements/
[3]:https://github.com/WebBluetoothCG/ble-test-peripheral-android
