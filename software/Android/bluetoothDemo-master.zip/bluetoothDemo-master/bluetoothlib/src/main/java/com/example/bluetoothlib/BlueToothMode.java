package com.example.bluetoothlib;

/**
 * Created by zhangyunfei on 16/9/19.
 */
public class BlueToothMode {
    private BlueToothMode() {
    }

    public static int MODE_AUTO = 0;//自动模式
    public static int MODE_SIMPLE = 0;//标准模式
    public static int MODE_BLE = 0;//BLE模式

}
