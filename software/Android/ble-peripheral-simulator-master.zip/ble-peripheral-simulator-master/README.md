# ble-peripheral-simulator
This project is custom characteristic extension of project ble-test-peripheral-android by WebBluetoothCG.
Available here: https://github.com/WebBluetoothCG/ble-test-peripheral-android
