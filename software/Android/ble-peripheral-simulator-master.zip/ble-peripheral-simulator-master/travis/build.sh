#!/bin/bash
./gradlew build --full-stacktrace
